$(function ()
{			  
  $('#dialog').hide();
 
  $('#clickMeButton').click(
      function()
      {
          $('#dialog').show();
          return false;
      }
  )
  
  $('#closeButton').click(
      function()
      {
          $('#dialog').hide();
          return false;
      }
  )

  var click = false,
  height = null,
  width = null;

  $(document).mousemove(function (e) {
      
      if (click == true) {
          $('#dialog').css({
              'width': e.pageX,
              'height': e.pageY
          })
          $('#header').css({
              'width': e.pageX
          })

          
          
      }
  });

  $('#dialog').click(function(e) {
      click = !click;
      return false;
  });

  $('html').click(function() {
      click = false;
  });				
});